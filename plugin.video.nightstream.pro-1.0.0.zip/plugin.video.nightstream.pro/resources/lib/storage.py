# -*- coding: utf-8 -*-
import json
import os
import sqlite3
import threading

import xbmcvfs

from .utils import item_identity, now_ts


class Storage:
    def __init__(self, addon):
        profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
        os.makedirs(profile, exist_ok=True)
        self.db_path = os.path.join(profile, "nightstream.db")
        self._lock = threading.RLock()
        self._init_db()

    def _connect(self):
        conn = sqlite3.connect(self.db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._lock, self._connect() as conn:
            conn.executescript(
                """
                PRAGMA journal_mode=WAL;
                PRAGMA synchronous=NORMAL;

                CREATE TABLE IF NOT EXISTS cache (
                    cache_key TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    updated_at INTEGER NOT NULL
                );

                CREATE TABLE IF NOT EXISTS favorites (
                    item_id TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    added_at INTEGER NOT NULL
                );

                CREATE TABLE IF NOT EXISTS history (
                    item_id TEXT PRIMARY KEY,
                    payload TEXT NOT NULL,
                    played_at INTEGER NOT NULL,
                    play_count INTEGER NOT NULL DEFAULT 1
                );
                """
            )

    def cache_get(self, key, max_age_seconds):
        with self._lock, self._connect() as conn:
            row = conn.execute(
                "SELECT payload, updated_at FROM cache WHERE cache_key = ?",
                (key,),
            ).fetchone()
        if not row:
            return None
        if now_ts() - int(row["updated_at"]) > max_age_seconds:
            return None
        try:
            return json.loads(row["payload"])
        except Exception:
            return None

    def cache_set(self, key, payload):
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO cache(cache_key, payload, updated_at)
                VALUES (?, ?, ?)
                ON CONFLICT(cache_key)
                DO UPDATE SET payload=excluded.payload, updated_at=excluded.updated_at
                """,
                (key, raw, now_ts()),
            )

    def cache_clear(self):
        with self._lock, self._connect() as conn:
            conn.execute("DELETE FROM cache")

    def favorite_toggle(self, item):
        item_id = item_identity(item)
        with self._lock, self._connect() as conn:
            exists = conn.execute(
                "SELECT 1 FROM favorites WHERE item_id = ?", (item_id,)
            ).fetchone()
            if exists:
                conn.execute("DELETE FROM favorites WHERE item_id = ?", (item_id,))
                return False
            conn.execute(
                "INSERT INTO favorites(item_id, payload, added_at) VALUES (?, ?, ?)",
                (
                    item_id,
                    json.dumps(item, ensure_ascii=False, separators=(",", ":")),
                    now_ts(),
                ),
            )
            return True

    def favorite_ids(self):
        with self._lock, self._connect() as conn:
            rows = conn.execute("SELECT item_id FROM favorites").fetchall()
        return {row["item_id"] for row in rows}

    def favorites(self):
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                "SELECT payload FROM favorites ORDER BY added_at DESC"
            ).fetchall()
        result = []
        for row in rows:
            try:
                result.append(json.loads(row["payload"]))
            except Exception:
                pass
        return result

    def add_history(self, item):
        item_id = item_identity(item)
        payload = json.dumps(item, ensure_ascii=False, separators=(",", ":"))
        with self._lock, self._connect() as conn:
            conn.execute(
                """
                INSERT INTO history(item_id, payload, played_at, play_count)
                VALUES (?, ?, ?, 1)
                ON CONFLICT(item_id)
                DO UPDATE SET
                    payload=excluded.payload,
                    played_at=excluded.played_at,
                    play_count=history.play_count + 1
                """,
                (item_id, payload, now_ts()),
            )

    def history(self, limit=250):
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                "SELECT payload FROM history ORDER BY played_at DESC LIMIT ?",
                (int(limit),),
            ).fetchall()
        result = []
        for row in rows:
            try:
                result.append(json.loads(row["payload"]))
            except Exception:
                pass
        return result

    def history_clear(self):
        with self._lock, self._connect() as conn:
            conn.execute("DELETE FROM history")
