# -*- coding: utf-8 -*-
import gzip
import hashlib
import json
import urllib.request

from .utils import normalize_space


class HttpClient:
    USER_AGENT = "Mozilla/5.0 (Kodi; NightStream Pro/1.0)"

    def __init__(self, storage, timeout=15, cache_seconds=3600):
        self.storage = storage
        self.timeout = timeout
        self.cache_seconds = cache_seconds

    def _cache_key(self, url):
        return "http:" + hashlib.sha256(url.encode("utf-8")).hexdigest()

    def get_text(self, url, force=False):
        key = self._cache_key(url)
        if not force:
            cached = self.storage.cache_get(key, self.cache_seconds)
            if isinstance(cached, dict) and "text" in cached:
                return cached["text"]

        request = urllib.request.Request(
            url,
            headers={
                "User-Agent": self.USER_AGENT,
                "Accept": "application/json, application/x-mpegURL, text/plain, */*",
                "Accept-Encoding": "gzip",
                "Cache-Control": "no-cache" if force else "max-age=0",
            },
        )

        with urllib.request.urlopen(request, timeout=self.timeout) as response:
            raw = response.read()
            if "gzip" in normalize_space(response.headers.get("Content-Encoding")).lower():
                raw = gzip.decompress(raw)
            charset = response.headers.get_content_charset() or "utf-8"

        try:
            text = raw.decode(charset)
        except (LookupError, UnicodeDecodeError):
            text = raw.decode("utf-8", errors="replace")

        self.storage.cache_set(key, {"text": text})
        return text
