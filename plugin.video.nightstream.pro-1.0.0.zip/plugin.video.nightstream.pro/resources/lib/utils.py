# -*- coding: utf-8 -*-
import base64
import hashlib
import json
import re
import time
import urllib.parse


QUALITY_ORDER = {
    "8k": 8000,
    "4320p": 4320,
    "4k": 4000,
    "2160p": 2160,
    "1440p": 1440,
    "1080p": 1080,
    "720p": 720,
    "576p": 576,
    "480p": 480,
    "360p": 360,
    "240p": 240,
}


def now_ts():
    return int(time.time())


def safe_int(value, default=0, minimum=None, maximum=None):
    try:
        number = int(value)
    except (TypeError, ValueError):
        number = default
    if minimum is not None:
        number = max(minimum, number)
    if maximum is not None:
        number = min(maximum, number)
    return number


def normalize_space(value):
    return re.sub(r"\s+", " ", str(value or "")).strip()


def quality_score(value):
    text = normalize_space(value).lower()
    for token, score in QUALITY_ORDER.items():
        if token in text:
            return score
    match = re.search(r"(\d{3,4})p", text)
    return int(match.group(1)) if match else 0


def item_identity(item):
    raw = "|".join([
        normalize_space(item.get("url")),
        normalize_space(item.get("title")).lower(),
    ])
    return hashlib.sha256(raw.encode("utf-8", errors="ignore")).hexdigest()


def encode_item(item):
    raw = json.dumps(item, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii")


def decode_item(value):
    padding = "=" * ((4 - len(value) % 4) % 4)
    raw = base64.urlsafe_b64decode((value + padding).encode("ascii"))
    return json.loads(raw.decode("utf-8"))


def build_plugin_url(base_url, **params):
    clean = {key: str(value) for key, value in params.items() if value is not None}
    return base_url + "?" + urllib.parse.urlencode(clean)
