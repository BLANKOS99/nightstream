# -*- coding: utf-8 -*-
import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed

from .utils import item_identity, normalize_space, quality_score


CATEGORY_ALIASES = {
    "Nouveautés": ("new", "latest", "nouveau", "nouveautés", "recent"),
    "Populaires": ("popular", "top", "most viewed", "tendance", "trending"),
    "Films": ("film", "films", "movie", "movies", "cinema"),
    "Clips": ("clip", "clips", "video", "videos"),
    "Live": ("live", "direct", "webcam"),
    "Studios": ("studio", "studios", "network"),
    "VR": ("vr", "virtual reality", "180", "360"),
    "4K / UHD": ("4k", "uhd", "2160p"),
    "Français": ("français", "french", "fr", "france"),
    "International": ("international", "world", "english", "español", "deutsch", "italiano"),
}


def _clean_item(raw, source_name=""):
    if not isinstance(raw, dict):
        return None

    title = normalize_space(
        raw.get("title")
        or raw.get("name")
        or raw.get("label")
        or raw.get("tvg-name")
    )
    url = normalize_space(
        raw.get("url")
        or raw.get("stream")
        or raw.get("stream_url")
        or raw.get("video")
        or raw.get("link")
    )
    if not title or not url:
        return None

    category = normalize_space(
        raw.get("category")
        or raw.get("group")
        or raw.get("group-title")
        or raw.get("genre")
    )
    quality = normalize_space(raw.get("quality") or raw.get("resolution"))
    thumb = normalize_space(
        raw.get("thumb")
        or raw.get("thumbnail")
        or raw.get("poster")
        or raw.get("image")
        or raw.get("tvg-logo")
    )

    try:
        views = int(raw.get("views") or raw.get("view_count") or 0)
    except (TypeError, ValueError):
        views = 0

    return {
        "title": title,
        "url": url,
        "category": category,
        "quality": quality,
        "thumb": thumb,
        "fanart": normalize_space(raw.get("fanart") or raw.get("background")),
        "plot": normalize_space(raw.get("plot") or raw.get("description")),
        "date": normalize_space(raw.get("date") or raw.get("published") or raw.get("added")),
        "duration": normalize_space(raw.get("duration")),
        "studio": normalize_space(raw.get("studio") or raw.get("provider")),
        "views": views,
        "source": normalize_space(raw.get("source") or source_name),
    }


def parse_json(text, source_name=""):
    data = json.loads(text)
    if isinstance(data, dict):
        items = (
            data.get("items")
            or data.get("videos")
            or data.get("results")
            or data.get("channels")
            or []
        )
    elif isinstance(data, list):
        items = data
    else:
        items = []

    result = []
    for raw in items:
        item = _clean_item(raw, source_name=source_name)
        if item:
            result.append(item)
    return result


def _m3u_attrs(line):
    return {
        key.lower(): value
        for key, value in re.findall(r'([\w-]+)="([^"]*)"', line)
    }


def parse_m3u(text, source_name=""):
    result = []
    pending = None

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue

        if line.startswith("#EXTINF"):
            attrs = _m3u_attrs(line)
            title = line.split(",", 1)[1].strip() if "," in line else "Sans titre"
            pending = {
                "title": title,
                "category": attrs.get("group-title", ""),
                "quality": attrs.get("quality", ""),
                "thumb": attrs.get("tvg-logo", ""),
                "fanart": attrs.get("fanart", ""),
                "plot": attrs.get("description", ""),
                "studio": attrs.get("provider", ""),
                "date": attrs.get("date", ""),
                "duration": attrs.get("duration", ""),
                "views": attrs.get("views", 0),
                "source": source_name,
            }
        elif pending and not line.startswith("#"):
            pending["url"] = line
            item = _clean_item(pending, source_name=source_name)
            if item:
                result.append(item)
            pending = None

    return result


def parse_catalog(text, source_name=""):
    stripped = text.lstrip()
    if stripped.startswith("{") or stripped.startswith("["):
        return parse_json(text, source_name=source_name)
    return parse_m3u(text, source_name=source_name)


def load_all_sources(urls, http, workers=4, force=False):
    clean_urls = []
    seen_urls = set()
    for url in urls:
        url = normalize_space(url)
        if url and url not in seen_urls:
            clean_urls.append(url)
            seen_urls.add(url)

    if not clean_urls:
        return [], []

    items = []
    errors = []

    def fetch(index, url):
        text = http.get_text(url, force=force)
        return parse_catalog(text, source_name="Source {}".format(index + 1))

    with ThreadPoolExecutor(max_workers=max(1, min(5, workers))) as pool:
        futures = {
            pool.submit(fetch, index, url): (index, url)
            for index, url in enumerate(clean_urls)
        }
        for future in as_completed(futures):
            index, url = futures[future]
            try:
                items.extend(future.result())
            except Exception as exc:
                errors.append({
                    "source": "Source {}".format(index + 1),
                    "url": url,
                    "error": str(exc),
                })

    deduped = {}
    for item in items:
        deduped[item_identity(item)] = item
    return list(deduped.values()), errors


def filter_category(items, label):
    if label in ("", "Tous"):
        return list(items)
    aliases = CATEGORY_ALIASES.get(label, (label.lower(),))
    result = []
    for item in items:
        haystack = " ".join([
            item.get("title", ""),
            item.get("category", ""),
            item.get("quality", ""),
            item.get("studio", ""),
            item.get("source", ""),
        ]).lower()
        if any(alias.lower() in haystack for alias in aliases):
            result.append(item)
    return result


def search_items(items, term):
    needle = normalize_space(term).lower()
    if not needle:
        return []
    result = []
    for item in items:
        haystack = " ".join([
            item.get("title", ""),
            item.get("category", ""),
            item.get("quality", ""),
            item.get("studio", ""),
            item.get("plot", ""),
            item.get("source", ""),
        ]).lower()
        if needle in haystack:
            result.append(item)
    return result


def sort_items(items, mode="quality"):
    if mode == "popular":
        return sorted(
            items,
            key=lambda item: (int(item.get("views") or 0), quality_score(item.get("quality"))),
            reverse=True,
        )
    if mode == "new":
        return sorted(
            items,
            key=lambda item: (item.get("date", ""), quality_score(item.get("quality"))),
            reverse=True,
        )
    if mode == "title":
        return sorted(items, key=lambda item: item.get("title", "").lower())
    return sorted(
        items,
        key=lambda item: (quality_score(item.get("quality")), item.get("title", "").lower()),
        reverse=True,
    )
