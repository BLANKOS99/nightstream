# -*- coding: utf-8 -*-
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from .catalog import CATEGORY_ALIASES, filter_category, load_all_sources, search_items, sort_items
from .http_client import HttpClient
from .storage import Storage
from .utils import (
    build_plugin_url,
    decode_item,
    encode_item,
    item_identity,
    normalize_space,
    safe_int,
)


ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
STORAGE = Storage(ADDON)


def _settings():
    cache_minutes = safe_int(ADDON.getSettingString("cache_minutes"), 60, 1, 1440)
    timeout = safe_int(ADDON.getSettingString("request_timeout"), 15, 5, 60)
    workers = safe_int(ADDON.getSettingString("parallel_workers"), 4, 1, 5)
    page_size = safe_int(ADDON.getSettingString("page_size"), 50, 10, 200)
    urls = [
        ADDON.getSettingString("source_{}".format(index)).strip()
        for index in range(1, 6)
    ]
    return {
        "cache_seconds": cache_minutes * 60,
        "timeout": timeout,
        "workers": workers,
        "page_size": page_size,
        "urls": [url for url in urls if url],
        "hide_without_thumb": ADDON.getSettingBool("hide_without_thumb"),
        "prefer_high_quality": ADDON.getSettingBool("prefer_high_quality"),
    }


def _adult_gate():
    if ADDON.getSettingBool("adult_confirmed"):
        return True

    accepted = xbmcgui.Dialog().yesno(
        "NightStream Pro — 18+",
        "Cette extension est strictement réservée aux adultes.",
        "Confirmez-vous avoir 18 ans ou plus ?",
    )
    if accepted:
        ADDON.setSettingBool("adult_confirmed", True)
        return True
    return False


def _folder(label, action, **params):
    params["action"] = action
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": "DefaultFolder.png"})
    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_plugin_url(BASE_URL, **params),
        li,
        isFolder=True,
    )


def _command(label, action, **params):
    params["action"] = action
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": "DefaultAddonProgram.png"})
    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_plugin_url(BASE_URL, **params),
        li,
        isFolder=False,
    )


def _video(item, favorite_ids):
    title = item.get("title", "Sans titre")
    quality = normalize_space(item.get("quality"))
    label = "[{}] {}".format(quality, title) if quality else title

    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "true")

    info = {
        "title": title,
        "plot": item.get("plot", ""),
        "genre": item.get("category", ""),
        "studio": item.get("studio", "") or item.get("source", ""),
        "dateadded": item.get("date", ""),
        "mediatype": "video",
    }
    li.setInfo("video", info)

    art = {}
    if item.get("thumb"):
        art["thumb"] = item["thumb"]
        art["icon"] = item["thumb"]
        art["poster"] = item["thumb"]
    if item.get("fanart"):
        art["fanart"] = item["fanart"]
    if art:
        li.setArt(art)

    encoded = encode_item(item)
    is_favorite = item_identity(item) in favorite_ids
    context_label = "Retirer des favoris" if is_favorite else "Ajouter aux favoris"
    li.addContextMenuItems([
        (
            context_label,
            "RunPlugin({})".format(
                build_plugin_url(BASE_URL, action="toggle_favorite", item=encoded)
            ),
        ),
    ])

    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_plugin_url(BASE_URL, action="play", item=encoded),
        li,
        isFolder=False,
    )


def _load(force=False):
    settings = _settings()
    http = HttpClient(
        STORAGE,
        timeout=settings["timeout"],
        cache_seconds=settings["cache_seconds"],
    )
    items, errors = load_all_sources(
        settings["urls"],
        http,
        workers=settings["workers"],
        force=force,
    )

    if settings["hide_without_thumb"]:
        items = [item for item in items if item.get("thumb")]

    if errors:
        xbmc.log(
            "[NightStream Pro] Source errors: {}".format(errors),
            xbmc.LOGWARNING,
        )
    return items, errors, settings


def show_root():
    _folder("⭐ Sélection", "list", category="Tous", sort="quality")
    _folder("🆕 Nouveautés", "list", category="Nouveautés", sort="new")
    _folder("🔥 Populaires", "list", category="Populaires", sort="popular")
    _folder("🎬 Films", "list", category="Films", sort="quality")
    _folder("▶ Clips", "list", category="Clips", sort="quality")
    _folder("🔴 Live", "list", category="Live", sort="title")
    _folder("🏢 Studios", "list", category="Studios", sort="title")
    _folder("🥽 VR", "list", category="VR", sort="quality")
    _folder("💎 4K / UHD", "list", category="4K / UHD", sort="quality")
    _folder("🇫🇷 Français", "list", category="Français", sort="quality")
    _folder("🌍 International", "list", category="International", sort="quality")
    _folder("🔎 Recherche", "search")
    _folder("❤️ Favoris", "favorites")
    _folder("🕘 Historique", "history")
    _folder("📡 État des sources", "source_status")
    _command("♻ Actualiser les catalogues", "refresh")
    _command("⚙ Paramètres", "settings")
    xbmcplugin.endOfDirectory(HANDLE)


def show_items(items, page=1, page_size=50):
    page = max(1, page)
    start = (page - 1) * page_size
    end = start + page_size
    chunk = items[start:end]
    favorite_ids = STORAGE.favorite_ids()

    for item in chunk:
        _video(item, favorite_ids)

    if end < len(items):
        _folder(
            "Page suivante  →",
            "list",
            category=PARAMS.get("category", "Tous"),
            sort=PARAMS.get("sort", "quality"),
            page=page + 1,
        )

    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE)


def list_catalog():
    items, errors, settings = _load(force=False)
    category = PARAMS.get("category", "Tous")
    sort_mode = PARAMS.get("sort", "quality")
    page = safe_int(PARAMS.get("page"), 1, 1)

    items = filter_category(items, category)
    items = sort_items(items, sort_mode)
    show_items(items, page=page, page_size=settings["page_size"])


def search():
    keyboard = xbmc.Keyboard("", "Rechercher")
    keyboard.doModal()
    if not keyboard.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE)
        return

    term = keyboard.getText()
    items, errors, settings = _load(force=False)
    items = search_items(items, term)
    items = sort_items(items, "quality")
    show_items(items, page=1, page_size=settings["page_size"])


def favorites():
    settings = _settings()
    show_items(
        sort_items(STORAGE.favorites(), "quality"),
        page=1,
        page_size=settings["page_size"],
    )


def history():
    settings = _settings()
    _command("Effacer l’historique", "clear_history")
    show_items(
        STORAGE.history(),
        page=1,
        page_size=settings["page_size"],
    )


def source_status():
    items, errors, settings = _load(force=False)
    configured = settings["urls"]

    if not configured:
        _command("Aucune source configurée — ouvrir les paramètres", "settings")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    error_urls = {entry.get("url") for entry in errors}
    for index, url in enumerate(configured, start=1):
        state = "❌ Erreur" if url in error_urls else "✅ Active"
        li = xbmcgui.ListItem(label="{} — Source {}".format(state, index))
        li.setInfo("video", {"plot": url})
        xbmcplugin.addDirectoryItem(HANDLE, "", li, isFolder=False)

    summary = xbmcgui.ListItem(label="{} éléments disponibles".format(len(items)))
    xbmcplugin.addDirectoryItem(HANDLE, "", summary, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)


def play():
    try:
        item = decode_item(PARAMS.get("item", ""))
    except Exception:
        xbmcgui.Dialog().notification(
            "NightStream Pro",
            "Lien invalide.",
            xbmcgui.NOTIFICATION_ERROR,
            4000,
        )
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    STORAGE.add_history(item)
    li = xbmcgui.ListItem(path=item.get("url", ""))
    li.setProperty("IsPlayable", "true")
    li.setInfo("video", {
        "title": item.get("title", ""),
        "plot": item.get("plot", ""),
    })
    xbmcplugin.setResolvedUrl(HANDLE, True, li)


def toggle_favorite():
    try:
        item = decode_item(PARAMS.get("item", ""))
        added = STORAGE.favorite_toggle(item)
        message = "Ajouté aux favoris" if added else "Retiré des favoris"
        xbmcgui.Dialog().notification(
            "NightStream Pro",
            message,
            xbmcgui.NOTIFICATION_INFO,
            2500,
        )
        xbmc.executebuiltin("Container.Refresh")
    except Exception as exc:
        xbmc.log("[NightStream Pro] Favorite error: {}".format(exc), xbmc.LOGERROR)


def refresh():
    STORAGE.cache_clear()
    items, errors, settings = _load(force=True)
    message = "{} éléments chargés".format(len(items))
    if errors:
        message += " — {} source(s) en erreur".format(len(errors))
    xbmcgui.Dialog().notification(
        "NightStream Pro",
        message,
        xbmcgui.NOTIFICATION_INFO,
        4500,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_history():
    STORAGE.history_clear()
    xbmcgui.Dialog().notification(
        "NightStream Pro",
        "Historique effacé.",
        xbmcgui.NOTIFICATION_INFO,
        2500,
    )
    xbmc.executebuiltin("Container.Refresh")


def open_settings():
    ADDON.openSettings()


def run():
    global PARAMS
    PARAMS = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

    if not _adult_gate():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    action = PARAMS.get("action", "")
    routes = {
        "": show_root,
        "list": list_catalog,
        "search": search,
        "favorites": favorites,
        "history": history,
        "source_status": source_status,
        "play": play,
        "toggle_favorite": toggle_favorite,
        "refresh": refresh,
        "clear_history": clear_history,
        "settings": open_settings,
    }

    handler = routes.get(action)
    if handler is None:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    handler()
