# NightStream Pro

Extension Kodi 21.x conçue comme une alternative rapide et modulaire aux gros agrégateurs.

## Fonctions
- Jusqu’à 5 catalogues JSON ou M3U autorisés
- Téléchargement parallèle
- Cache SQLite avec mode WAL
- Pagination
- Déduplication automatique
- Recherche
- Favoris
- Historique
- Filtres par catégorie et qualité
- Diagnostic des sources
- Confirmation 18+

Aucun site, flux ou contenu n’est fourni avec l’extension.
