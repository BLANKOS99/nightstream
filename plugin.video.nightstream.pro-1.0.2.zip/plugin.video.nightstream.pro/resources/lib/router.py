# -*- coding: utf-8 -*-
import json
import os
import sys
import traceback
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from .catalog import filter_category, load_all_sources, search_items, sort_items
from .http_client import HttpClient
from .storage import Storage
from .utils import (
    build_plugin_url,
    decode_item,
    encode_item,
    item_identity,
    normalize_space,
    safe_int,
)

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
STORAGE = Storage(ADDON)
PARAMS = {}


def _setting(setting_id, default=""):
    try:
        value = ADDON.getSetting(setting_id)
        return value if value != "" else default
    except Exception:
        return default


def _setting_bool(setting_id, default=False):
    value = str(_setting(setting_id, "true" if default else "false")).strip().lower()
    return value in ("true", "1", "yes", "on")


def _settings():
    return {
        "cache_seconds": safe_int(_setting("cache_minutes", "60"), 60, 1, 1440) * 60,
        "timeout": safe_int(_setting("request_timeout", "15"), 15, 5, 60),
        "workers": safe_int(_setting("parallel_workers", "3"), 3, 1, 5),
        "page_size": safe_int(_setting("page_size", "50"), 50, 10, 200),
        "urls": [
            value for value in
            [_setting("source_{}".format(index), "").strip() for index in range(1, 6)]
            if value
        ],
        "hide_without_thumb": _setting_bool("hide_without_thumb", False),
    }


def _adult_gate():
    if _setting_bool("adult_confirmed", False):
        return True

    accepted = xbmcgui.Dialog().yesno(
        "NightStream Pro — 18+",
        "Cette extension est strictement réservée aux personnes majeures.",
        "Confirmez-vous avoir 18 ans ou plus ?",
    )
    if accepted:
        try:
            ADDON.setSetting("adult_confirmed", "true")
        except Exception:
            pass
        return True
    return False


def _demo_items():
    return [
        {
            "title": "Démonstration 1080p — Big Buck Bunny",
            "url": "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8",
            "category": "Nouveautés, Populaires, Films, Clips, Français",
            "quality": "1080p",
            "thumb": "",
            "fanart": "",
            "plot": "Flux HLS public de démonstration intégré pour vérifier le fonctionnement de l’addon.",
            "date": "2026-07-17",
            "duration": "",
            "studio": "Mux Test Streams",
            "views": 1000,
            "source": "Démonstration intégrée",
        },
        {
            "title": "Démonstration — Tears of Steel",
            "url": "https://test-streams.mux.dev/tos_ismc/main.m3u8",
            "category": "Nouveautés, Films, 4K / UHD, International",
            "quality": "1080p",
            "thumb": "",
            "fanart": "",
            "plot": "Second flux HLS public de démonstration.",
            "date": "2026-07-17",
            "duration": "",
            "studio": "Mux Test Streams",
            "views": 900,
            "source": "Démonstration intégrée",
        },
    ]


def _folder(label, action, **params):
    params["action"] = action
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": "DefaultFolder.png"})
    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_plugin_url(BASE_URL, **params),
        li,
        isFolder=True,
    )


def _command(label, action, **params):
    params["action"] = action
    li = xbmcgui.ListItem(label=label)
    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_plugin_url(BASE_URL, **params),
        li,
        isFolder=False,
    )


def _message_item(label, plot=""):
    li = xbmcgui.ListItem(label=label)
    try:
        li.setInfo("video", {"title": label, "plot": plot, "mediatype": "video"})
    except Exception:
        pass
    xbmcplugin.addDirectoryItem(HANDLE, "", li, isFolder=False)


def _video(item, favorite_ids):
    title = item.get("title", "Sans titre")
    quality = normalize_space(item.get("quality"))
    label = "[{}] {}".format(quality, title) if quality else title

    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "true")

    safe_info = {
        "title": title,
        "plot": item.get("plot", ""),
        "genre": item.get("category", ""),
        "studio": item.get("studio", "") or item.get("source", ""),
        "mediatype": "video",
    }
    try:
        li.setInfo("video", safe_info)
    except Exception:
        pass

    art = {}
    if item.get("thumb"):
        art.update({
            "thumb": item["thumb"],
            "icon": item["thumb"],
            "poster": item["thumb"],
        })
    if item.get("fanart"):
        art["fanart"] = item["fanart"]
    if art:
        try:
            li.setArt(art)
        except Exception:
            pass

    encoded = encode_item(item)
    is_favorite = item_identity(item) in favorite_ids
    context_label = "Retirer des favoris" if is_favorite else "Ajouter aux favoris"
    try:
        li.addContextMenuItems([
            (
                context_label,
                "RunPlugin({})".format(
                    build_plugin_url(BASE_URL, action="toggle_favorite", item=encoded)
                ),
            ),
        ])
    except Exception:
        pass

    xbmcplugin.addDirectoryItem(
        HANDLE,
        build_plugin_url(BASE_URL, action="play", item=encoded),
        li,
        isFolder=False,
    )


def _load(force=False):
    settings = _settings()
    errors = []

    if settings["urls"]:
        try:
            http = HttpClient(
                STORAGE,
                timeout=settings["timeout"],
                cache_seconds=settings["cache_seconds"],
            )
            items, errors = load_all_sources(
                settings["urls"],
                http,
                workers=settings["workers"],
                force=force,
            )
        except Exception as exc:
            items = []
            errors = [{"source": "Catalogue", "url": "", "error": str(exc)}]
    else:
        items = []

    # The built-in legal demonstration remains available so the add-on never opens empty.
    if not items:
        items = _demo_items()

    if settings["hide_without_thumb"]:
        filtered = [item for item in items if item.get("thumb")]
        if filtered:
            items = filtered

    return items, errors, settings


def show_root():
    _folder("Sélection", "list", category="Tous", sort="quality")
    _folder("Nouveautés", "list", category="Nouveautés", sort="new")
    _folder("Populaires", "list", category="Populaires", sort="popular")
    _folder("Films", "list", category="Films", sort="quality")
    _folder("Clips", "list", category="Clips", sort="quality")
    _folder("Live", "list", category="Live", sort="title")
    _folder("Studios", "list", category="Studios", sort="title")
    _folder("VR", "list", category="VR", sort="quality")
    _folder("4K / UHD", "list", category="4K / UHD", sort="quality")
    _folder("Français", "list", category="Français", sort="quality")
    _folder("International", "list", category="International", sort="quality")
    _folder("Recherche", "search")
    _folder("Favoris", "favorites")
    _folder("Historique", "history")
    _folder("État des sources", "source_status")
    _command("Actualiser les catalogues", "refresh")
    _command("Paramètres", "settings")
    xbmcplugin.endOfDirectory(HANDLE)


def show_items(items, page=1, page_size=50):
    page = max(1, page)
    start = (page - 1) * page_size
    end = start + page_size
    favorite_ids = STORAGE.favorite_ids()

    for item in items[start:end]:
        _video(item, favorite_ids)

    if not items:
        _message_item("Aucun élément disponible.")

    if end < len(items):
        _folder(
            "Page suivante",
            "list",
            category=PARAMS.get("category", "Tous"),
            sort=PARAMS.get("sort", "quality"),
            page=page + 1,
        )

    xbmcplugin.setContent(HANDLE, "videos")
    try:
        sort_method = getattr(
            xbmcplugin,
            "SORT_METHOD_LABEL_IGNORE_THE",
            getattr(xbmcplugin, "SORT_METHOD_LABEL", 1),
        )
        xbmcplugin.addSortMethod(HANDLE, sort_method)
    except Exception:
        pass
    xbmcplugin.endOfDirectory(HANDLE)


def list_catalog():
    items, errors, settings = _load(force=False)
    category = PARAMS.get("category", "Tous")
    sort_mode = PARAMS.get("sort", "quality")
    page = safe_int(PARAMS.get("page"), 1, 1)

    items = sort_items(filter_category(items, category), sort_mode)
    show_items(items, page=page, page_size=settings["page_size"])


def search():
    keyboard = xbmc.Keyboard("", "Rechercher")
    keyboard.doModal()
    if not keyboard.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE)
        return

    items, errors, settings = _load(force=False)
    results = sort_items(search_items(items, keyboard.getText()), "quality")
    show_items(results, page=1, page_size=settings["page_size"])


def favorites():
    settings = _settings()
    show_items(
        sort_items(STORAGE.favorites(), "quality"),
        page=1,
        page_size=settings["page_size"],
    )


def history():
    settings = _settings()
    _command("Effacer l’historique", "clear_history")
    show_items(
        STORAGE.history(),
        page=1,
        page_size=settings["page_size"],
    )


def source_status():
    items, errors, settings = _load(force=False)

    if not settings["urls"]:
        _message_item(
            "Mode démonstration intégré",
            "Aucune URL externe n’est configurée. Les vidéos publiques de test sont utilisées.",
        )
    else:
        error_urls = {entry.get("url") for entry in errors}
        for index, url in enumerate(settings["urls"], start=1):
            state = "Erreur" if url in error_urls else "Active"
            _message_item("{} — Source {}".format(state, index), url)

    _message_item("{} élément(s) disponible(s)".format(len(items)))
    xbmcplugin.endOfDirectory(HANDLE)


def play():
    try:
        item = decode_item(PARAMS.get("item", ""))
        url = item.get("url", "")
        if not url:
            raise ValueError("URL vidéo vide")
        STORAGE.add_history(item)
        li = xbmcgui.ListItem(path=url)
        li.setProperty("IsPlayable", "true")
        try:
            li.setInfo("video", {
                "title": item.get("title", ""),
                "plot": item.get("plot", ""),
                "mediatype": "video",
            })
        except Exception:
            pass
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    except Exception as exc:
        xbmc.log("[NightStream Pro] Play error: {}".format(exc), xbmc.LOGERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


def toggle_favorite():
    item = decode_item(PARAMS.get("item", ""))
    added = STORAGE.favorite_toggle(item)
    xbmcgui.Dialog().notification(
        "NightStream Pro",
        "Ajouté aux favoris" if added else "Retiré des favoris",
        xbmcgui.NOTIFICATION_INFO,
        2500,
    )
    xbmc.executebuiltin("Container.Refresh")


def refresh():
    STORAGE.cache_clear()
    items, errors, settings = _load(force=True)
    message = "{} élément(s) chargé(s)".format(len(items))
    if errors:
        message += " — catalogue externe indisponible, démonstration utilisée"
    xbmcgui.Dialog().notification(
        "NightStream Pro",
        message,
        xbmcgui.NOTIFICATION_INFO,
        4500,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_history():
    STORAGE.history_clear()
    xbmcgui.Dialog().notification(
        "NightStream Pro",
        "Historique effacé.",
        xbmcgui.NOTIFICATION_INFO,
        2500,
    )
    xbmc.executebuiltin("Container.Refresh")


def open_settings():
    ADDON.openSettings()


def run():
    global PARAMS
    try:
        PARAMS = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))

        if not _adult_gate():
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return

        routes = {
            "": show_root,
            "list": list_catalog,
            "search": search,
            "favorites": favorites,
            "history": history,
            "source_status": source_status,
            "play": play,
            "toggle_favorite": toggle_favorite,
            "refresh": refresh,
            "clear_history": clear_history,
            "settings": open_settings,
        }

        handler = routes.get(PARAMS.get("action", ""), show_root)
        handler()

    except Exception as exc:
        details = "{}: {}".format(type(exc).__name__, exc)
        xbmc.log(
            "[NightStream Pro] Fatal error:\n{}".format(traceback.format_exc()),
            xbmc.LOGERROR,
        )
        xbmcgui.Dialog().ok(
            "NightStream Pro — erreur corrigible",
            details,
            "Installez la dernière version puis relancez l’extension.",
        )
        try:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        except Exception:
            pass
